//
// Created by wmw13 on 19/02/2021.
//

#ifndef TESTSAMPLECODE_GAHEURISTIC_H
#define TESTSAMPLECODE_GAHEURISTIC_H

#include "GeneticAlgorithm.h"

void GAHeuristic();

#endif //TESTSAMPLECODE_GAHEURISTIC_H
