//
// Created by wmw13 on 05/03/2021.
//

#ifndef TESTSAMPLECODE_REPAIROPERATORS_H
#define TESTSAMPLECODE_REPAIROPERATORS_H

#include "../LocalSearchAndGenerateTour/LocalSearches.h"
#include <list>

class RepairOperators {
public:
    static void basicRepair(int* route);
};


#endif //TESTSAMPLECODE_REPAIROPERATORS_H
