#include "ACOOnClustersHeuristic.h"

/*
 * Runs the internal Clustered ACO.
 */
void ACOOnClustersHeuristic(){
    ACOOnClusters();
}