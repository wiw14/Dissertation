#ifndef TESTSAMPLECODE_CACOHEURISTIC_H
#define TESTSAMPLECODE_CACOHEURISTIC_H

//Runs the CACO metaheuristic.
void CACOHeuristic(int,int,int,double,double,double,double,int,int);


#endif //TESTSAMPLECODE_CACOHEURISTIC_H
