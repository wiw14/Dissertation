#ifndef TESTSAMPLECODE_GAHEURISTIC_H
#define TESTSAMPLECODE_GAHEURISTIC_H

#include "GeneticAlgorithm.h"

void GAHeuristic(int,int,int,int,int,int,int,int);

#endif //TESTSAMPLECODE_GAHEURISTIC_H
