#ifndef TESTSAMPLECODE_ACOONCLUSTERSHEURISTIC_H
#define TESTSAMPLECODE_ACOONCLUSTERSHEURISTIC_H
#include "ACOOnClusters.h"

void ACOOnClustersHeuristic(int,int,int,double,double,double,double,int,int);


#endif //TESTSAMPLECODE_ACOONCLUSTERSHEURISTIC_H
